export enum UserStatusEnum {
    Active = "active",
    Disabled = "disabled",
    Frozen = "frozen"
}

