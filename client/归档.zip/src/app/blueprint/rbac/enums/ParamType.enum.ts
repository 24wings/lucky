export enum ParamsTypeEnum {
    Text = "text",
    Input = "input",
}