export enum QueryAttributeTypeEnum {
    Date = "Date",
    String = "String",
    Number = "Number",
    Boolean = "Boolean"
}