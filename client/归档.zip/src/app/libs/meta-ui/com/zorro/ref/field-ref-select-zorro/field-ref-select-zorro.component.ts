import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'field-ref-select-zorro',
  templateUrl: './field-ref-select-zorro.component.html',
  styleUrls: ['./field-ref-select-zorro.component.css']
})
export class FieldRefSelectZorroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
