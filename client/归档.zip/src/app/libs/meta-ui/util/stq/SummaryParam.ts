


export class SummaryParam {
    fieldName: string;
    sumName: string;
    sumTitle: string;
    sumType: string;
    sumValue: string;
}