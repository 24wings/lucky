import { MetaCom } from "../../meta/MetaCom";

export abstract class CheckDataActionEvent {
    metaCom: MetaCom;
    data: any;
}




