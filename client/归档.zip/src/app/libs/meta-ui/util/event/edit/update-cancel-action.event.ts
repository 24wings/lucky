import { MetaCom } from "../../meta/MetaCom";

export class UpdateCancelActionEvent {
    metaCom: MetaCom;

}

export class CreateCancelActionEvent {
    metaCom: MetaCom;
}
export class CreateSuccessActionEvent {
    metaCom: MetaCom;
}

export class UpdateSuccessActionEvent {
    metaCom: MetaCom
}