import { Field } from "../../../meta/Field";

export interface IFieldIO {
    __field__: Field;
    field: Field
}