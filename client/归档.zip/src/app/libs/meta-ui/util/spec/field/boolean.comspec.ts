import { BasicComspce } from "./basic.comspec";

export abstract class BooleanComSpec extends BasicComspce<any>  {
}