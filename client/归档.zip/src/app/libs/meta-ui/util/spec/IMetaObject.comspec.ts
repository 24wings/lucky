interface IMetaObjectComSpec extends IAfterCreateSuceess {

}