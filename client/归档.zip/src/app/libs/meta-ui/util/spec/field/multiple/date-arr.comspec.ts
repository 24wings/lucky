import { BasicComspce } from "../basic.comspec";

export abstract class DateArrComSpec extends BasicComspce<any>  {
}