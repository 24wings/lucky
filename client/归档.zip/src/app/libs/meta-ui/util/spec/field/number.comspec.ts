import { BasicComspce } from "./basic.comspec";

export abstract class NumberComSpec extends BasicComspce<any>  {
}  