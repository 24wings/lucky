export class Pictures extends String {

}