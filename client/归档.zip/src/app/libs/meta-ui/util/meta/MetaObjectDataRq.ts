import { MetaCom } from "./MetaCom";

export class MetaObjectDataRq {
    metaObject: MetaCom;
    dataItem: any;
}