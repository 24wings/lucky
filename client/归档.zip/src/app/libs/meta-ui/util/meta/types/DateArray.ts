export class DateArray extends Array<Date> {

}
