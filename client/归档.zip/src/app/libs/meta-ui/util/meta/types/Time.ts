export class Time extends Date {

}