export enum ModeEnum {
    Show = "show",
    Query = "query",
    Create = "create",
    Update = "update",
    Delete = "delete",
    MainShow = "main_show",
    Info = "info"

}  