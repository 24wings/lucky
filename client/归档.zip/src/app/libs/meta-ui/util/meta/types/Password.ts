
export class Password extends String {

}