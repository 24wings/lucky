export class SelectMany extends Array {

}