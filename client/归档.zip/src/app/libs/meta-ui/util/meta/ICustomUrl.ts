export interface ICustomUrl {
    create?: string;
    update?: string;
    delete?: string;
    query?: string;
}