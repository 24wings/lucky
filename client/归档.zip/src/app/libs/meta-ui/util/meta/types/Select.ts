export class Select<T> {

}