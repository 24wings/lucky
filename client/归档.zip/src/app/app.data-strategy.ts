import { IndexedDbStrategyService } from "app/libs/meta-ui/service/data-strategy/IndexedDbStrategy.service";
import { OnlineStrategyService } from "app/libs/meta-ui/service/data-strategy/OnlineStrategy.service";

export const DataStrategy = OnlineStrategyService;